"""AI Hub Topic-wise Everyday Text Dialogue (dataSetSn=543) → seq2seq pairs.

Schema in this distribution:

    {
      "info": [{
        "annotations": {
          "subject": "교육",
          "speaker_type": "1:1",
          "text": "1 : ...\\n2 : ...\\n3 : ..."
        }
      }]
    }

The `text` field is a single string with `<speaker_id> : <utterance>` per line.
Consecutive same-speaker lines are merged before pairing.
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Iterator, List

from ._utils import (
    adjacent_pairs,
    merge_speaker_turns,
    passes_basic_filters,
)
from .common import make_seq2seq_record, write_jsonl

SOURCE = "aihub_topic_dialogue"
LANG = "ko"
RAW_DIR = Path("data/raw_manual/aihub/topic_dialogue")
OUTPUT = Path("data/interim/ko_aihub_topic_dialogue.jsonl")

LINE_RE = re.compile(r"^\s*(\S+)\s*:\s*(.+?)\s*$")


def _parse_text(text: str) -> list[tuple[str, str]]:
    pairs: list[tuple[str, str]] = []
    for line in (text or "").split("\n"):
        m = LINE_RE.match(line)
        if not m:
            continue
        pairs.append((m.group(1), m.group(2)))
    return pairs


def _walk(raw_dir: Path) -> Iterator[dict]:
    for path in sorted(raw_dir.rglob("*.json")):
        try:
            yield json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            print(f"[{SOURCE}] could not read {path}: {exc!r}")


def build_records(raw_dir: Path = RAW_DIR) -> List[dict]:
    if not raw_dir.exists():
        print(f"[{SOURCE}] manual data not found at {raw_dir} — skipping.")
        return []

    records: List[dict] = []
    for data in _walk(raw_dir):
        info = data.get("info") or []
        if not info:
            continue
        ann = (info[0] or {}).get("annotations") or {}
        topic = ann.get("subject") or "일상 대화"
        turns = merge_speaker_turns(_parse_text(ann.get("text") or ""))
        for prev, nxt in adjacent_pairs(turns):
            if not (passes_basic_filters(prev) and passes_basic_filters(nxt)):
                continue
            record = make_seq2seq_record(
                lang=LANG,
                source=SOURCE,
                topic=str(topic),
                input_context=prev,
                target_output=nxt,
                meta={"is_synthetic": False},
            )
            if record:
                records.append(record)
    return records


if __name__ == "__main__":
    write_jsonl(build_records(), OUTPUT)
